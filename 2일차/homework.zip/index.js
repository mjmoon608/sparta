// function order_product() {
//   const customerName = $("#customer-name");
//   const customNum = $("#customer-num");
//   const customerAdress = $("#customer-adress");
//   const customerTel = $("#customer-tel");

//   console.log(customerName);

//   // alert("주문이 완료되었습니다!");
// }
// console.log("customerName");
document
  .querySelector("#customer-name")
  .addEventListener("click", function (e) {
    console.log("hi");
  });
